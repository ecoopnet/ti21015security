package jp.techinstitute.osaka.security.enshu;

/**
 * Created by mi on 15/06/05.
 */
public class MySettings {
    public static final int getValue(){
        return 123 * 4467;
    }
}
